package chatAddDb;

public class Identifier {
	final static String ID = "\tID";
	final static String CheckAccount = "\tCheckAccount";
	final static String LoginFailure = "\tLoginFailure";
	final static String LoginSuccess = "\tLoginSuccess";
	final static String Initialize = "\tInitialize";
	final static String FriendData = "\tFriendData";
	final static String ChatroomData = "\tChatroomData";
	final static String RecordData = "\tRecordData";
	final static String StateThree = "\tStateThree";
}
