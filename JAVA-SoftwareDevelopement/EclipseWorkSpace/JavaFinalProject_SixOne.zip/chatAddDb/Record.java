package chatAddDb;

public class Record {
	
	public String sender;
	public String MSG;
	
	public Record(String sender, String MSG) {
		this.sender = sender;
		this.MSG = MSG;
	}
}
