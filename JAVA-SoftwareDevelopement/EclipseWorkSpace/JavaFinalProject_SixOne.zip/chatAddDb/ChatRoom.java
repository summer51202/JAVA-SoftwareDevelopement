package chatAddDb;

public class ChatRoom {
	
	public String code;
	public String roomName;
	
	public ChatRoom(String code, String roomName) {
		this.code = code;
		this.roomName = roomName;
	}
}
