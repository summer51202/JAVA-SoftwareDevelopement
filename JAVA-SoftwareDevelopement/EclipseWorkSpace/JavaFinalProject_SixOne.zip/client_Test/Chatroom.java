package client_Test;

public class Chatroom {
	public String code;
	public String roomName;
	
	public Chatroom(String code, String roomName) {
		this.code = code;
		this.roomName = roomName;
	}
}
