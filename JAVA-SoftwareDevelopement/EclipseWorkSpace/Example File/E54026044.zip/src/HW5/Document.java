package HW5;

public class Document {
	public String toString() {
		return text;
	}
	public void setText(String str) {
		text = str;
	}
	
	public String text;
}
