package HW6;

public interface IOperation {
	public abstract String perform(String num1, String num2);
}
